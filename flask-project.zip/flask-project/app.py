from flask import Flask, render_template, request, redirect, url_for, flash
import requests

app = Flask(__name__)
app.secret_key = 'mysecretkey'

USERNAME = "admin"
PASSWORD = "1234"

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == USERNAME and password == PASSWORD:
            flash('ورود موفقیت‌آمیز بود!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('نام کاربری یا رمز عبور اشتباه است.', 'danger')
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    try:
        response = requests.get('https://jsonplaceholder.typicode.com/posts?userId=1')
        posts = response.json()  
    except:
        posts = []
        flash('خطا در دریافت داده از سرور!', 'danger')
    
    return render_template('dashboard.html', posts=posts)

if __name__ == '__main__':
    app.run(debug=True)